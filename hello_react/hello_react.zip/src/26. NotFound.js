const NotFound = () => {
    return (
        <>
            <div>
                <h1>잘못된 요청입니다.</h1>
            </div>
        </>
    )
}

export default NotFound
