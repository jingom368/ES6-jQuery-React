const Intro = () => {
    return (
        <>
            <div>
                <h1>Intro</h1>
            </div>
        </>
    )
}

export default Intro
