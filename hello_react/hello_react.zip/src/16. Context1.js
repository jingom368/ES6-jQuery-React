import { createContext } from 'react'

const Context1 = createContext({ name: '홍길동' })

export default Context1 // create '홍길동'
