import UseCallbackTest from './14. useCallbackTest'
import UseMemoTest from './13. useMemoTest'

const App2 = () => {
    return (
        <>
            {/* <UseMemoTest /> */}
            <UseCallbackTest />
        </>
    )
}

export default App2
